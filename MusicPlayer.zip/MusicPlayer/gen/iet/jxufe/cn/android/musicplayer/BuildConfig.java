/** Automatically generated file. DO NOT MODIFY */
package iet.jxufe.cn.android.musicplayer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}